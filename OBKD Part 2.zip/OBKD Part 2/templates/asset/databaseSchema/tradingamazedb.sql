SELECT * FROM customertable;
